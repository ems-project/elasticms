!function(){"use strict";console.log("Load admin JS")}();
//# sourceMappingURL=admin.js.map